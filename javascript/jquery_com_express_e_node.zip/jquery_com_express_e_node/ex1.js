mult = function(a, b=1) { return a * b }
resultado = mult(10);
console.log(resultado);
